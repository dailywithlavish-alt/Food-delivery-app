// Replace inside Flutter lib/main.dart

import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Scaffold(
      appBar: AppBar(title: Text("NutriLift")),
      body: Center(child: Text("App Ready 🚀")),
    ),
  ));
}
