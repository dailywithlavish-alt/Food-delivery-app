NutriLift Full App (Frontend + Backend)

SETUP:

FRONTEND:
1. flutter create app
2. replace lib folder with provided structure

BACKEND:
cd backend
npm install
node server.js

APIs:
- /create-order
- /verify-payment
